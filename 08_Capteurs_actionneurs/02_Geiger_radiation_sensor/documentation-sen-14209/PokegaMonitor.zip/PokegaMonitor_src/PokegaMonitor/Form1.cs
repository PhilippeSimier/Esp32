﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PokegaMonitor
{
    public partial class MainWindow : Form
    {
        int index = 0;
        const int signLen = 500;
        Point[] sign = new Point[signLen];
        Point[] cpm = new Point[signLen];
     
        BufferedGraphicsContext context;
        BufferedGraphics doubleBuffer;

        public MainWindow()
        {
            InitializeComponent();
            context = BufferedGraphicsManager.Current;
            doubleBuffer = context.Allocate(graphMonitor.CreateGraphics(), graphMonitor.DisplayRectangle);
            for (int i = 0; i < sign.Length; i++)
            {
                sign[i].X = i;
                sign[i].Y = graphMonitor.Height;
                cpm[i].X = i;
                cpm[i].Y = graphMonitor.Height;
            }
        }

        private void connectBtn_Click(object sender, EventArgs e)
        {
            if (serial.IsOpen)
            {
                serial.Close();
                connectBtn.Text = "connect";
            }
            else
            {
                try
                {
                    Console.WriteLine(comList.Text);
                    serial.PortName = comList.Text;
                    serial.Open();
                    if (serial.IsOpen)
                    {
                        connectBtn.Text = "disconnect";
                        string msg = serial.ReadLine();
                    }
                }
                catch (Exception ex)
                {
                    string msg = ex.StackTrace;
                }
            }
        }

        delegate void viewLabelDelegate(string[] val);
        void viewLabel(string[] values)
        {
            timeLabel.Text = values[0] + "[hour] " + values[1] + "[sec]";
            cpmLabel.Text = values[3] + " [cpm]";
            usvLabel.Text = values[4] + "±" + values[5] + " [uSv/h]";
        }

        private void serial_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            string msg="";
            try
            {
                msg = serial.ReadLine();
            }
            catch (Exception ex)
            {
            }
            //Console.WriteLine(msg);
            string[] values = msg.Split(',');

            if (values.Length == 6)
            {
                viewLabelDelegate vld = new viewLabelDelegate(viewLabel);
                BeginInvoke(vld, new object[] { values });

                Graphics g = doubleBuffer.Graphics;
                Pen blue = new Pen(Color.Blue);
                Pen red = new Pen(Color.Red);
                Pen green = new Pen(Color.Green);
                Pen gray = new Pen(Color.LightGray);

                sign[index].Y = graphMonitor.Height - (int)(Convert.ToDouble(values[2])) * 10;
                cpm[index].Y = (int)(graphMonitor.Height - Convert.ToDouble(values[3]) * 10);

                g.Clear(Color.White);
                for (int i = 0; i < 10; i++)
                {
                    g.DrawLine(gray, 0, graphMonitor.Height - i * 10, graphMonitor.Width, graphMonitor.Height - i * 10);
                }
                g.DrawLines(blue, sign);
                g.DrawLines(red, cpm);
                g.DrawLine(green, index, 0, index, graphMonitor.Height);
                doubleBuffer.Render();
                index++;
                index %= signLen;
            }
        }
    }
}
