﻿namespace PokegaMonitor
{
    partial class MainWindow
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainWindow));
            this.connectBtn = new System.Windows.Forms.Button();
            this.graphMonitor = new System.Windows.Forms.PictureBox();
            this.serial = new System.IO.Ports.SerialPort(this.components);
            this.timeLabel = new System.Windows.Forms.Label();
            this.cpmLabel = new System.Windows.Forms.Label();
            this.usvLabel = new System.Windows.Forms.Label();
            this.comList = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.graphMonitor)).BeginInit();
            this.SuspendLayout();
            // 
            // connectBtn
            // 
            this.connectBtn.Location = new System.Drawing.Point(437, 7);
            this.connectBtn.Name = "connectBtn";
            this.connectBtn.Size = new System.Drawing.Size(75, 23);
            this.connectBtn.TabIndex = 0;
            this.connectBtn.Text = "connect";
            this.connectBtn.UseVisualStyleBackColor = true;
            this.connectBtn.Click += new System.EventHandler(this.connectBtn_Click);
            // 
            // graphMonitor
            // 
            this.graphMonitor.BackColor = System.Drawing.SystemColors.Window;
            this.graphMonitor.Location = new System.Drawing.Point(13, 36);
            this.graphMonitor.Name = "graphMonitor";
            this.graphMonitor.Size = new System.Drawing.Size(500, 100);
            this.graphMonitor.TabIndex = 1;
            this.graphMonitor.TabStop = false;
            // 
            // serial
            // 
            this.serial.PortName = "COM3";
            this.serial.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serial_DataReceived);
            // 
            // timeLabel
            // 
            this.timeLabel.Location = new System.Drawing.Point(13, 9);
            this.timeLabel.Name = "timeLabel";
            this.timeLabel.Size = new System.Drawing.Size(115, 18);
            this.timeLabel.TabIndex = 2;
            this.timeLabel.Text = "0[hour]    0[sec]";
            this.timeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cpmLabel
            // 
            this.cpmLabel.Location = new System.Drawing.Point(134, 9);
            this.cpmLabel.Name = "cpmLabel";
            this.cpmLabel.Size = new System.Drawing.Size(85, 18);
            this.cpmLabel.TabIndex = 3;
            this.cpmLabel.Text = "0.000 [cpm]";
            this.cpmLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // usvLabel
            // 
            this.usvLabel.Location = new System.Drawing.Point(225, 9);
            this.usvLabel.Name = "usvLabel";
            this.usvLabel.Size = new System.Drawing.Size(141, 18);
            this.usvLabel.TabIndex = 4;
            this.usvLabel.Text = "0.000±0.000 [uSv/h]";
            this.usvLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comList
            // 
            this.comList.FormattingEnabled = true;
            this.comList.Items.AddRange(new object[] {
            "COM1",
            "COM2",
            "COM3",
            "COM4",
            "COM5",
            "COM6",
            "COM7",
            "COM8",
            "COM9"});
            this.comList.Location = new System.Drawing.Point(372, 8);
            this.comList.Name = "comList";
            this.comList.Size = new System.Drawing.Size(59, 20);
            this.comList.TabIndex = 5;
            this.comList.Text = "COM1";
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(525, 147);
            this.Controls.Add(this.comList);
            this.Controls.Add(this.usvLabel);
            this.Controls.Add(this.cpmLabel);
            this.Controls.Add(this.timeLabel);
            this.Controls.Add(this.graphMonitor);
            this.Controls.Add(this.connectBtn);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainWindow";
            this.Text = "Pocket Geiger Monitor for Arduino";
            ((System.ComponentModel.ISupportInitialize)(this.graphMonitor)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button connectBtn;
        private System.Windows.Forms.PictureBox graphMonitor;
        private System.IO.Ports.SerialPort serial;
        private System.Windows.Forms.Label timeLabel;
        private System.Windows.Forms.Label cpmLabel;
        private System.Windows.Forms.Label usvLabel;
        private System.Windows.Forms.ComboBox comList;
    }
}

